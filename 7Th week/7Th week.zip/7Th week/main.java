public class main {
    public static void main(String[] args){
        Temporal newuser = new Temporal("5267SF", "Andres", "SEB", 7);
        Normal newuser1 = new Normal("7RF7847", "ELPEPE", "ETECT", 3000);
        Supervisor newuser2 = new Supervisor("77F783", "ANDRRRE", "LASO", 3000, 200);
        
        System.out.println(newuser);
        System.out.println("========================");
        System.out.println(newuser1);
        System.out.println("========================");
        System.out.println(newuser2);
    }
}
